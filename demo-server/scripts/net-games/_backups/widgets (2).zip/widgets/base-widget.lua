--[[
    Widget Base System for Pure Sprite Widget Framework
    Base widget classes and lifecycle management
]]

-- Base Widget Class
local BaseWidget = {}
BaseWidget.__index = BaseWidget

function BaseWidget.new(player_id, widget_id, properties)
    local self = setmetatable({}, BaseWidget)
    
    self.player_id = player_id
    self.id = widget_id
    self.type = "base"
    
    -- Initialize properties with defaults
    self.properties = self:_mergeProperties(properties or {})
    
    -- Widget state
    self.state = {
        mounted = false,
        visible = true,
        enabled = true,
        dirty = true,  -- Start dirty to ensure initial render
        focused = false
    }
    
    -- Parent-child hierarchy
    self.parent = nil
    self.children = {}
    
    -- Sprite allocations (to be filled by subclasses)
    self.allocations = {}
    
    return self
end

-- Merge user properties with defaults
function BaseWidget:_mergeProperties(user_props)
    local defaults = {
        -- Basic properties
        x = 0,
        y = 0,
        z = 0,
        scale = 1.0,
        scale_x = 1.0,
        scale_y = 1.0,
        rotation = 0,
        opacity = 255,
        
        -- Color
        color = {r = 255, g = 255, b = 255, a = 255},
        
        -- Sprite properties
        texture = nil,
        animation = nil,
        animation_state = "default",
        
        -- Dimensions
        width = 32,
        height = 32,
        
        -- Visibility and interaction
        visible = true,
        enabled = true,
        
        -- Parent reference
        parent = nil
    }
    
    local merged = {}
    
    -- Copy defaults
    for key, value in pairs(defaults) do
        merged[key] = value
    end
    
    -- Override with user properties
    if user_props then
        for key, value in pairs(user_props) do
            if key == "color" and type(value) == "table" then
                -- Ensure color has all components
                merged.color = {
                    r = value.r or defaults.color.r,
                    g = value.g or defaults.color.g,
                    b = value.b or defaults.color.b,
                    a = value.a or defaults.color.a
                }
            elseif key == "scale" then
                -- Set both scale_x and scale_y if scale is provided
                merged.scale = value
                merged.scale_x = value
                merged.scale_y = value
            else
                merged[key] = value
            end
        end
    end
    
    return merged
end

-- Lifecycle: Build the widget (create sprites)
function BaseWidget:build()
    self.state.mounted = true
    self.state.dirty = true
    return true
end

-- Lifecycle: Update widget properties
function BaseWidget:update(new_properties)
    if not self.state.mounted then
        return false, "Widget not mounted"
    end
    
    local old_props = self.properties
    self.properties = self:_mergeProperties(new_properties)
    
    -- Check if any visual properties changed
    local visual_props = {"x", "y", "z", "scale", "scale_x", "scale_y", "rotation", 
                         "opacity", "color", "texture", "animation", "width", "height"}
    
    for _, prop in ipairs(visual_props) do
        if not self:_areEqual(old_props[prop], self.properties[prop]) then
            self.state.dirty = true
            break
        end
    end
    
    -- Handle parent changes
    if old_props.parent ~= self.properties.parent then
        self:setParent(self.properties.parent)
    end
    
    return true
end

-- Lifecycle: Render the widget (update sprites)
function BaseWidget:render(sprite_manager)
    if not self.state.mounted or not self.state.visible then
        return false, "Widget not visible or not mounted"
    end
    
    if not self.state.dirty then
        return true  -- Nothing to render
    end
    
    self.state.dirty = false
    return true
end

-- Lifecycle: Dispose of widget resources
function BaseWidget:dispose(sprite_manager)
    -- Release all sprite allocations
    if sprite_manager and self.allocations then
        for _, alloc_id in ipairs(self.allocations) do
            sprite_manager:releaseAllocation(self.player_id, alloc_id, self.id)
        end
    end
    
    -- Remove from parent
    if self.parent then
        self:removeFromParent()
    end
    
    -- Dispose children
    for _, child_id in ipairs(self.children) do
        -- Note: Actual disposal handled by widget framework
    end
    
    self.state.mounted = false
    self.allocations = {}
    self.children = {}
    self.parent = nil
    
    return true
end

-- Transformations
function BaseWidget:setPosition(x, y)
    self.properties.x = x or self.properties.x
    self.properties.y = y or self.properties.y
    self.state.dirty = true
end

function BaseWidget:setScale(sx, sy)
    if sy then
        self.properties.scale_x = sx
        self.properties.scale_y = sy
    else
        self.properties.scale = sx
        self.properties.scale_x = sx
        self.properties.scale_y = sx
    end
    self.state.dirty = true
end

function BaseWidget:setRotation(rotation)
    self.properties.rotation = rotation or 0
    self.state.dirty = true
end

function BaseWidget:setOpacity(opacity)
    self.properties.opacity = math.max(0, math.min(255, opacity or 255))
    self.state.dirty = true
end

function BaseWidget:setColor(r, g, b, a)
    self.properties.color = {
        r = r or self.properties.color.r,
        g = g or self.properties.color.g,
        b = b or self.properties.color.b,
        a = a or self.properties.color.a
    }
    self.state.dirty = true
end

function BaseWidget:setVisible(visible)
    if self.state.visible ~= visible then
        self.state.visible = visible
        self.state.dirty = true
    end
end

function BaseWidget:setEnabled(enabled)
    self.state.enabled = enabled
end

function BaseWidget:setFocused(focused)
    self.state.focused = focused
end

-- Parent-child hierarchy
function BaseWidget:addChild(child_widget)
    if not child_widget or not child_widget.id then
        return false, "Invalid child widget"
    end
    
    -- Remove from current parent if any
    if child_widget.parent and child_widget.parent ~= self.id then
        -- Note: Actual removal handled by widget framework
    end
    
    -- Add to children
    table.insert(self.children, child_widget.id)
    child_widget.parent = self.id
    
    self.state.dirty = true  -- Parent needs re-layout
    return true
end

function BaseWidget:removeChild(child_id)
    for i, id in ipairs(self.children) do
        if id == child_id then
            table.remove(self.children, i)
            self.state.dirty = true
            return true
        end
    end
    return false, "Child not found"
end

function BaseWidget:setParent(parent_id)
    self.properties.parent = parent_id
    self.parent = parent_id
end

function BaseWidget:removeFromParent()
    if self.parent then
        -- Note: Actual removal handled by widget framework
        self.parent = nil
        self.properties.parent = nil
    end
end

-- Hit testing (for input events)
function BaseWidget:hitTest(x, y)
    if not self.state.visible or not self.state.enabled then
        return false
    end
    
    local widget_x = self.properties.x
    local widget_y = self.properties.y
    local width = self.properties.width or 32
    local height = self.properties.height or 32
    
    return x >= widget_x and x <= widget_x + width and
           y >= widget_y and y <= widget_y + height
end

-- Get world position (accounting for parent transformations)
function BaseWidget:getWorldPosition()
    local x = self.properties.x
    local y = self.properties.y
    
    -- TODO: Account for parent transformations when parent system is implemented
    return x, y
end

-- Mark as dirty (needs re-render)
function BaseWidget:markDirty()
    self.state.dirty = true
end

-- Utility: Check if two values are equal (deep compare for tables)
function BaseWidget:_areEqual(a, b)
    if type(a) ~= type(b) then
        return false
    end
    
    if type(a) == "table" then
        if a.r and b.r then  -- Color table
            return a.r == b.r and a.g == b.g and a.b == b.b and a.a == b.a
        end
        -- Simple table comparison (not recursive for performance)
        return tostring(a) == tostring(b)
    end
    
    return a == b
end

-- Sprite Widget (basic sprite display)
SpriteWidget = setmetatable({}, {__index = BaseWidget})
SpriteWidget.__index = SpriteWidget

function SpriteWidget.new(player_id, widget_id, properties)
    local self = setmetatable(BaseWidget.new(player_id, widget_id, properties), SpriteWidget)
    self.type = "sprite"
    self.sprite_allocation = nil
    return self
end

function SpriteWidget:build()
    if not BaseWidget.build(self) then
        return false
    end
    
    return true
end

function SpriteWidget:render(sprite_manager)
    if not BaseWidget.render(self, sprite_manager) then
        return false
    end
    
    if not self.properties.texture then
        return false, "No texture specified"
    end
    
    -- Get or create sprite allocation
    if not self.sprite_allocation then
        self.sprite_allocation, error = sprite_manager:getAllocation(
            self.player_id,
            self.properties.texture,
            self.properties.animation,
            self.id
        )
        
        if not self.sprite_allocation then
            return false, error
        end
        
        table.insert(self.allocations, self.sprite_allocation)
    end
    
    -- Draw sprite
    local draw_props = {
        x = self.properties.x,
        y = self.properties.y,
        z = self.properties.z,
        scale_x = self.properties.scale_x,
        scale_y = self.properties.scale_y,
        rotation = self.properties.rotation,
        opacity = self.properties.opacity,
        color = self.properties.color
    }
    
    return sprite_manager:drawSprite(self.player_id, self.sprite_allocation, draw_props)
end

function SpriteWidget:dispose(sprite_manager)
    if self.sprite_allocation and sprite_manager then
        sprite_manager:releaseAllocation(self.player_id, self.sprite_allocation, self.id)
        self.sprite_allocation = nil
    end
    
    return BaseWidget.dispose(self, sprite_manager)
end

-- Text Sprite Widget (text rendered as character sprites)
TextSpriteWidget = setmetatable({}, {__index = BaseWidget})
TextSpriteWidget.__index = TextSpriteWidget

function TextSpriteWidget.new(player_id, widget_id, properties)
    local self = setmetatable(BaseWidget.new(player_id, widget_id, properties), TextSpriteWidget)
    self.type = "text_sprite"
    
    -- Text-specific properties
    self.properties.text = properties.text or ""
    self.properties.font = properties.font or "THICK"
    self.properties.font_scale = properties.font_scale or 2.0
    self.properties.alignment = properties.alignment or "left"
    
    -- Character sprites
    self.char_sprites = {}  -- {char_index = {allocation_id, x_offset}}
    self.char_allocations = {}
    
    return self
end

function TextSpriteWidget:build()
    if not BaseWidget.build(self) then
        return false
    end
    
    return true
end

function TextSpriteWidget:render(sprite_manager)
    if not BaseWidget.render(self, sprite_manager) then
        return false
    end
    
    -- Clear existing character allocations
    for _, alloc_id in ipairs(self.char_allocations) do
        sprite_manager:releaseAllocation(self.player_id, alloc_id, self.id)
    end
    self.char_allocations = {}
    self.char_sprites = {}
    
    local text = tostring(self.properties.text or "")
    if text == "" then
        return true  -- Nothing to render
    end
    
    local font = sprite_manager.FONTS[self.properties.font or "THICK"]
    if not font then
        return false, "Invalid font type"
    end
    
    local char_width = font.char_width * (self.properties.font_scale or 2.0)
    local total_width = #text * char_width
    local start_x = self.properties.x
    
    -- Apply alignment
    if self.properties.alignment == "center" then
        start_x = start_x - total_width / 2
    elseif self.properties.alignment == "right" then
        start_x = start_x - total_width
    end
    
    -- Render each character
    for i = 1, #text do
        local char = text:sub(i, i)
        local char_index = sprite_manager:getCharIndex(char)
        
        -- Get font allocation for this character
        local allocation_id, error = sprite_manager:getFontAllocation(
            self.player_id,
            self.properties.font,
            char_index
        )
        
        if allocation_id then
            -- Calculate character position
            local char_x = start_x + (i - 1) * char_width
            
            -- Draw character sprite
            local draw_props = {
                x = char_x,
                y = self.properties.y,
                z = self.properties.z,
                scale_x = self.properties.font_scale,
                scale_y = self.properties.font_scale,
                rotation = self.properties.rotation,
                opacity = self.properties.opacity,
                color = self.properties.color
            }
            
            sprite_manager:drawSprite(self.player_id, allocation_id, draw_props)
            
            -- Store for cleanup
            table.insert(self.char_sprites, {
                allocation_id = allocation_id,
                x_offset = (i - 1) * char_width
            })
            table.insert(self.char_allocations, allocation_id)
        end
    end
    
    -- Update widget dimensions based on text
    self.properties.width = total_width
    self.properties.height = font.char_height * (self.properties.font_scale or 2.0)
    
    return true
end

function TextSpriteWidget:update(new_properties)
    -- Check if text changed
    local text_changed = new_properties and 
                        new_properties.text and 
                        new_properties.text ~= self.properties.text
    
    local result, error = BaseWidget.update(self, new_properties)
    
    if text_changed and result then
        self.state.dirty = true  -- Force re-render for text changes
    end
    
    return result, error
end

function TextSpriteWidget:dispose(sprite_manager)
    -- Clean up character allocations
    for _, alloc_id in ipairs(self.char_allocations) do
        if sprite_manager then
            sprite_manager:releaseAllocation(self.player_id, alloc_id, self.id)
        end
    end
    
    self.char_sprites = {}
    self.char_allocations = {}
    
    return BaseWidget.dispose(self, sprite_manager)
end

-- Container Widget (parent widget for layout management)
ContainerWidget = setmetatable({}, {__index = BaseWidget})
ContainerWidget.__index = ContainerWidget

function ContainerWidget.new(player_id, widget_id, properties)
    local self = setmetatable(BaseWidget.new(player_id, widget_id, properties), ContainerWidget)
    self.type = "container"
    
    -- Container-specific properties
    self.properties.layout = properties.layout or "absolute"
    self.properties.spacing = properties.spacing or 0
    self.properties.padding = properties.padding or 0
    self.properties.background = properties.background
    
    -- Background sprite
    self.background_allocation = nil
    
    return self
end

function ContainerWidget:build()
    if not BaseWidget.build(self) then
        return false
    end
    
    return true
end

function ContainerWidget:render(sprite_manager)
    if not BaseWidget.render(self, sprite_manager) then
        return false
    end
    
    -- Render background if specified
    if self.properties.background and not self.background_allocation then
        self.background_allocation, error = sprite_manager:getAllocation(
            self.player_id,
            self.properties.background,
            nil,
            self.id
        )
        
        if self.background_allocation then
            table.insert(self.allocations, self.background_allocation)
        end
    end
    
    if self.background_allocation then
        local draw_props = {
            x = self.properties.x,
            y = self.properties.y,
            z = self.properties.z - 1,  -- Background behind children
            scale_x = self.properties.scale_x,
            scale_y = self.properties.scale_y,
            rotation = self.properties.rotation,
            opacity = self.properties.opacity,
            color = self.properties.color
        }
        
        sprite_manager:drawSprite(self.player_id, self.background_allocation, draw_props)
    end
    
    return true
end

function ContainerWidget:updateLayout(widget_registry)
    if not self.state.mounted or self.children == 0 then
        return
    end
    
    local start_x = self.properties.x + self.properties.padding
    local start_y = self.properties.y + self.properties.padding
    local current_x = start_x
    local current_y = start_y
    
    local max_child_width = 0
    local max_child_height = 0
    
    -- Position children based on layout
    for _, child_id in ipairs(self.children) do
        local child = widget_registry[child_id]
        if child and child.state.mounted and child.state.visible then
            if self.properties.layout == "vertical" then
                child:setPosition(current_x, current_y)
                current_y = current_y + (child.properties.height or 32) + self.properties.spacing
                max_child_width = math.max(max_child_width, child.properties.width or 32)
                
            elseif self.properties.layout == "horizontal" then
                child:setPosition(current_x, current_y)
                current_x = current_x + (child.properties.width or 32) + self.properties.spacing
                max_child_height = math.max(max_child_height, child.properties.height or 32)
                
            elseif self.properties.layout == "absolute" then
                -- Children use absolute coordinates relative to container
                -- No automatic positioning needed
            end
        end
    end
    
    -- Update container dimensions based on children
    if self.properties.layout == "vertical" then
        self.properties.width = max_child_width + (self.properties.padding * 2)
        self.properties.height = (current_y - start_y) + self.properties.padding
    elseif self.properties.layout == "horizontal" then
        self.properties.width = (current_x - start_x) + self.properties.padding
        self.properties.height = max_child_height + (self.properties.padding * 2)
    end
    
    self.state.dirty = true
end

function ContainerWidget:addChild(child_widget)
    local success, error = BaseWidget.addChild(self, child_widget)
    if success then
        self:markDirty()  -- Container needs layout update
    end
    return success, error
end

function ContainerWidget:removeChild(child_id)
    local success, error = BaseWidget.removeChild(self, child_id)
    if success then
        self:markDirty()  -- Container needs layout update
    end
    return success, error
end

function ContainerWidget:dispose(sprite_manager)
    if self.background_allocation and sprite_manager then
        sprite_manager:releaseAllocation(self.player_id, self.background_allocation, self.id)
        self.background_allocation = nil
    end
    
    return BaseWidget.dispose(self, sprite_manager)
end

-- Export widget classes
return {
    BaseWidget = BaseWidget,
    SpriteWidget = SpriteWidget,
    TextSpriteWidget = TextSpriteWidget,
    ContainerWidget = ContainerWidget
}